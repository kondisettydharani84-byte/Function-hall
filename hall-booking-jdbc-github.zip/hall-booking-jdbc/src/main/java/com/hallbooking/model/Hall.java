package com.hallbooking.model;
public class Hall { private int id,capacity; private String name,location,description,imageUrl; private double pricePerDay;
 public Hall(int id,String name,String location,int capacity,double pricePerDay,String description,String imageUrl){this.id=id;this.name=name;this.location=location;this.capacity=capacity;this.pricePerDay=pricePerDay;this.description=description;this.imageUrl=imageUrl;}
 public int getId(){return id;} public String getName(){return name;} public String getLocation(){return location;} public int getCapacity(){return capacity;} public double getPricePerDay(){return pricePerDay;} public String getDescription(){return description;} public String getImageUrl(){return imageUrl;}}
