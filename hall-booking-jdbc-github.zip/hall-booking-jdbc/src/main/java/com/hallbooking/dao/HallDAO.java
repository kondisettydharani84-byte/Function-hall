package com.hallbooking.dao;
import com.hallbooking.model.Hall; import com.hallbooking.util.DBConnection; import java.sql.*; import java.util.*;
public class HallDAO {
 public List<Hall> findAll() throws SQLException {List<Hall> x=new ArrayList<>(); String q="SELECT * FROM halls WHERE active=true ORDER BY price_per_day"; try(Connection c=DBConnection.getConnection();PreparedStatement p=c.prepareStatement(q);ResultSet r=p.executeQuery()){while(r.next())x.add(map(r));}return x;}
 public Hall findById(int id)throws SQLException{String q="SELECT * FROM halls WHERE id=? AND active=true";try(Connection c=DBConnection.getConnection();PreparedStatement p=c.prepareStatement(q)){p.setInt(1,id);try(ResultSet r=p.executeQuery()){return r.next()?map(r):null;}}}
 public boolean isAvailable(int hallId,Date d)throws SQLException{String q="SELECT COUNT(*) FROM bookings WHERE hall_id=? AND event_date=? AND status IN ('PENDING','CONFIRMED')";try(Connection c=DBConnection.getConnection();PreparedStatement p=c.prepareStatement(q)){p.setInt(1,hallId);p.setDate(2,d);try(ResultSet r=p.executeQuery()){r.next();return r.getInt(1)==0;}}}
 private Hall map(ResultSet r)throws SQLException{return new Hall(r.getInt("id"),r.getString("name"),r.getString("location"),r.getInt("capacity"),r.getDouble("price_per_day"),r.getString("description"),r.getString("image_url"));}
}
