CREATE DATABASE IF NOT EXISTS hall_booking_db;
USE hall_booking_db;
DROP TABLE IF EXISTS payments; DROP TABLE IF EXISTS bookings; DROP TABLE IF EXISTS halls;
CREATE TABLE halls(id INT PRIMARY KEY AUTO_INCREMENT,name VARCHAR(100) NOT NULL,location VARCHAR(150) NOT NULL,capacity INT NOT NULL,price_per_day DECIMAL(10,2) NOT NULL,description VARCHAR(500),image_url VARCHAR(500),active BOOLEAN DEFAULT TRUE);
CREATE TABLE bookings(id INT PRIMARY KEY AUTO_INCREMENT,hall_id INT NOT NULL,customer_name VARCHAR(120) NOT NULL,email VARCHAR(160) NOT NULL,phone VARCHAR(20) NOT NULL,event_type VARCHAR(80) NOT NULL,event_date DATE NOT NULL,guests INT NOT NULL,amount DECIMAL(10,2) NOT NULL,status ENUM('PENDING','CONFIRMED','CANCELLED') DEFAULT 'PENDING',created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,CONSTRAINT fk_booking_hall FOREIGN KEY(hall_id) REFERENCES halls(id));
CREATE TABLE payments(id INT PRIMARY KEY AUTO_INCREMENT,booking_id INT NOT NULL,method ENUM('UPI','CARD','CASH') NOT NULL,transaction_ref VARCHAR(100),amount DECIMAL(10,2) NOT NULL,status ENUM('SUCCESS','PENDING','FAILED') DEFAULT 'PENDING',paid_at TIMESTAMP NULL,CONSTRAINT fk_payment_booking FOREIGN KEY(booking_id) REFERENCES bookings(id));
INSERT INTO halls(name,location,capacity,price_per_day,description,image_url) VALUES
('Royal Grand Hall','Tirupati',500,25000,'Elegant air-conditioned hall for weddings, receptions and large events.','https://images.unsplash.com/photo-1519167758481-83f550bb49b3?auto=format&fit=crop&w=1200&q=80'),
('Lotus Mini Hall','Tirupati',150,10000,'Cozy and affordable hall for birthdays, meetings and small functions.','https://images.unsplash.com/photo-1507504031003-b417219a0fde?auto=format&fit=crop&w=1200&q=80'),
('Crystal Convention Hall','Tirupati',800,40000,'Spacious convention venue with premium seating and stage area.','https://images.unsplash.com/photo-1505373877841-8d25f7d46678?auto=format&fit=crop&w=1200&q=80'),
('Green Garden Hall','Tirupati',300,18000,'Beautiful venue for celebrations with a garden-style atmosphere.','https://images.unsplash.com/photo-1478146896981-b80fe463b330?auto=format&fit=crop&w=1200&q=80');
