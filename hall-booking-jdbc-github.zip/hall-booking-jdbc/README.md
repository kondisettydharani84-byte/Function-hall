# HallHive — Online Hall Booking System

Java Servlet + JDBC + MySQL + HTML/CSS/JavaScript project.

## Features
- Hall catalogue
- Date availability check
- Online booking form
- Duplicate-date protection
- Demo UPI/Card/Cash payment recording
- Booking confirmation/reference
- Admin booking dashboard

> Payment is DEMO mode only. No real money is charged.

## Run
1. Install JDK 17+, Maven, MySQL 8+, and Tomcat 10+.
2. Run `database/schema.sql` in MySQL.
3. Edit `src/main/java/com/hallbooking/util/DBConnection.java` and set your MySQL password.
4. Run `mvn clean package`.
5. Copy `target/hall-booking.war` to Tomcat `webapps/`.
6. Open `http://localhost:8080/hall-booking/`.

For production, add authentication, HTTPS, CSRF protection, server-side validation, connection pooling, and a real payment gateway.
